import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./replit_integrations/auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express,
): Promise<Server> {
  setupAuth(app);

  app.get(api.prompts.list.path, async (req, res) => {
    const prompts = await storage.getPrompts();
    res.json(prompts);
  });

  app.post(api.prompts.create.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const input = api.prompts.create.input.parse(req.body);
      const userId = (req.user as any).id; // Replit Auth user ID
      const prompt = await storage.createPrompt(input, userId);
      res.status(201).json(prompt);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.delete(api.prompts.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid ID" });
    }

    await storage.deletePrompt(id);
    res.status(204).send();
  });

  // Seed data if empty
  const existingPrompts = await storage.getPrompts();
  if (existingPrompts.length === 0) {
    const { db } = await import("./db");
    const { prompts } = await import("@shared/schema");
    
    await db.insert(prompts).values([
      { text: "Indian woman wearing luxury silk saree", category: "Woman Saree" },
      { text: "Stylish Indian man in professional black suit", category: "Man Posh" },
      { text: "Modern stylish girl fashion portrait", category: "Girl Stylish" },
      { text: "Elegant Indian couple photoshoot in luxury setting", category: "Couple Luxury" }
    ]);
  }

  return httpServer;
}
