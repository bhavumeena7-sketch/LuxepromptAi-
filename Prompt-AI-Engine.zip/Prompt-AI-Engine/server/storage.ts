import { db } from "./db";
import { prompts, type Prompt, type InsertPrompt } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getPrompts(): Promise<Prompt[]>;
  createPrompt(prompt: InsertPrompt, userId: string): Promise<Prompt>;
  deletePrompt(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getPrompts(): Promise<Prompt[]> {
    return await db.select().from(prompts);
  }

  async createPrompt(prompt: InsertPrompt, userId: string): Promise<Prompt> {
    const [newPrompt] = await db.insert(prompts).values({ ...prompt, userId }).returning();
    return newPrompt;
  }

  async deletePrompt(id: number): Promise<void> {
    await db.delete(prompts).where(eq(prompts.id, id));
  }
}

export const storage = new DatabaseStorage();
