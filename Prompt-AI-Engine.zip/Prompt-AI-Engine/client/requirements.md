## Packages
framer-motion | Smooth animations for UI transitions
lucide-react | Beautiful icons

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
