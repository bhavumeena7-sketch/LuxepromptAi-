import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { InsertPrompt, Prompt } from "@shared/schema";
import { z } from "zod";

export function usePrompts() {
  const { toast } = useToast();

  return useQuery({
    queryKey: [api.prompts.list.path],
    queryFn: async () => {
      const res = await fetch(api.prompts.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch prompts");
      return api.prompts.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreatePrompt() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertPrompt) => {
      const validated = api.prompts.create.input.parse(data);
      const res = await fetch(api.prompts.create.path, {
        method: api.prompts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        const errorData = await res.json();
        if (res.status === 400) {
           const parsedError = api.prompts.create.responses[400].parse(errorData);
           throw new Error(parsedError.message);
        }
        throw new Error("Failed to create prompt");
      }
      return api.prompts.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.prompts.list.path] });
      toast({
        title: "Success",
        description: "New base prompt added to library",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useDeletePrompt() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.prompts.delete.path, { id });
      const res = await fetch(url, { 
        method: api.prompts.delete.method,
        credentials: "include" 
      });

      if (!res.ok) {
        if (res.status === 404) {
           const parsedError = api.prompts.delete.responses[404].parse(await res.json());
           throw new Error(parsedError.message);
        }
        throw new Error("Failed to delete prompt");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.prompts.list.path] });
      toast({
        title: "Deleted",
        description: "Prompt removed from library",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
