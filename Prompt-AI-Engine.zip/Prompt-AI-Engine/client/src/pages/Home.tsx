import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { usePrompts, useCreatePrompt, useDeletePrompt } from "@/hooks/use-prompts";
import { Button } from "@/components/ui/button";
import { Sparkles, Copy, Settings, Trash2, Plus, Zap, LogIn, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

// === Constants ===
const CATEGORIES = ["Woman Saree", "Man Posh", "Girl Stylish", "Couple Luxury"];
const MOODS = ["Elegant", "Luxury", "Cinematic", "Romantic", "Edgy", "Cyberpunk", "Vintage"];
const LIGHTING_OPTIONS = ["soft studio lighting", "natural sunlight", "cinematic volumetric lighting"];
const STYLE_SUFFIX = "ultra realistic, 8K resolution, high detail, professional photography, masterpiece";

export default function Home() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const { data: basePrompts, isLoading: isPromptsLoading } = usePrompts();
  const { mutate: createPrompt, isPending: isCreating } = useCreatePrompt();
  const { mutate: deletePrompt, isPending: isDeleting } = useDeletePrompt();
  const { toast } = useToast();

  const [category, setCategory] = useState(CATEGORIES[0]);
  const [mood, setMood] = useState(MOODS[0]);
  const [output, setOutput] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Admin state
  const [newPromptText, setNewPromptText] = useState("");
  const [adminCategory, setAdminCategory] = useState(CATEGORIES[0]);

  // Loading state
  if (isAuthLoading || isPromptsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  // === Logic ===
  const handleGenerate = () => {
    setIsGenerating(true);
    
    // Find a base prompt for this category
    const categoryPrompts = basePrompts?.filter(p => p.category === category) || [];
    const baseText = categoryPrompts.length > 0 
      ? categoryPrompts[Math.floor(Math.random() * categoryPrompts.length)].text 
      : `High quality portrait of ${category}`; // Fallback

    // Generate variations
    const results = LIGHTING_OPTIONS.map(light => {
      return `${baseText}, ${mood} mood, ${light}, 85mm DSLR, ${STYLE_SUFFIX}`;
    });

    // Simulate "thinking" delay for better UX
    setTimeout(() => {
      setOutput(results.join("\n\n---\n\n"));
      setIsGenerating(false);
    }, 600);
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    toast({
      title: "Copied to clipboard! 📋",
      description: "Ready to paste into your image generator.",
      className: "bg-primary text-white border-none"
    });
  };

  const handleAddBasePrompt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPromptText.trim()) return;
    
    createPrompt({
      text: newPromptText,
      category: adminCategory
    }, {
      onSuccess: () => setNewPromptText("")
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      {/* === Header === */}
      <header className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-rose-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-gradient">PromptGen AI</h1>
              <p className="text-xs text-muted-foreground font-medium hidden sm:block">Professional Image Prompts</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {!user ? (
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/api/login"} className="hidden sm:flex gap-2">
                <LogIn className="w-4 h-4" /> Sign In
              </Button>
            ) : (
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-muted-foreground hidden sm:block">
                  Hi, {user.firstName || "Creator"}
                </span>
                <div className="w-8 h-8 rounded-full bg-muted border border-border overflow-hidden">
                  {user.profileImageUrl ? (
                    <img src={user.profileImageUrl} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-primary/20 flex items-center justify-center text-primary font-bold">
                      {(user.firstName?.[0] || "U").toUpperCase()}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="flex-grow w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
        
        {/* === Generator Card === */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-card rounded-3xl border border-white/5 shadow-2xl overflow-hidden relative"
        >
          {/* Ambient background glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />

          <div className="p-6 md:p-8 lg:p-10 space-y-8 relative z-10">
            <div className="space-y-2">
              <h2 className="text-3xl md:text-4xl font-bold font-display">Create Masterpieces</h2>
              <p className="text-muted-foreground text-lg">Generate ultra-detailed prompts for Midjourney, Stable Diffusion, and DALL-E.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Subject Category</label>
                <div className="relative">
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full appearance-none bg-muted/50 border border-input rounded-xl px-4 py-4 text-base focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all cursor-pointer hover:bg-muted/80"
                  >
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground">
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Aesthetic Mood</label>
                <div className="relative">
                  <select 
                    value={mood}
                    onChange={(e) => setMood(e.target.value)}
                    className="w-full appearance-none bg-muted/50 border border-input rounded-xl px-4 py-4 text-base focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all cursor-pointer hover:bg-muted/80"
                  >
                    {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground">
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  </div>
                </div>
              </div>
            </div>

            <Button 
              variant="premium" 
              size="lg" 
              className="w-full text-lg font-bold h-16 rounded-2xl"
              onClick={handleGenerate}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Generating Magic...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-5 w-5 fill-current" /> Generate Pro Prompts
                </>
              )}
            </Button>

            <AnimatePresence>
              {output && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4"
                >
                  <div className="relative group">
                    <textarea 
                      readOnly
                      value={output}
                      className="w-full h-64 bg-[#0a0a0a] border border-border rounded-xl p-6 font-mono text-sm leading-relaxed text-gray-300 focus:outline-none resize-none shadow-inner"
                    />
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="bg-black/80 text-xs px-2 py-1 rounded text-white backdrop-blur">Read Only</span>
                    </div>
                  </div>
                  
                  <Button 
                    variant="secondary" 
                    className="w-full py-6 text-base font-semibold"
                    onClick={handleCopy}
                  >
                    <Copy className="mr-2 h-5 w-5" /> Copy All Prompts
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* === Admin Panel === */}
        {user && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="border border-red-900/30 bg-red-950/5 rounded-3xl p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-6 text-red-500">
              <Settings className="w-6 h-6" />
              <h3 className="text-xl font-bold">Admin: Base Prompts Library</h3>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Add New Form */}
              <div className="lg:col-span-1 space-y-4">
                <form onSubmit={handleAddBasePrompt} className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">Category</label>
                    <select 
                      value={adminCategory}
                      onChange={(e) => setAdminCategory(e.target.value)}
                      className="w-full bg-background border border-input rounded-lg p-3 text-sm focus:ring-2 focus:ring-red-500/20 outline-none"
                    >
                      {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase">Base Prompt Text</label>
                    <textarea 
                      value={newPromptText}
                      onChange={(e) => setNewPromptText(e.target.value)}
                      placeholder="e.g. Indian woman wearing luxury silk saree standing in a palace..."
                      className="w-full h-32 bg-background border border-input rounded-lg p-3 text-sm focus:ring-2 focus:ring-red-500/20 outline-none resize-none"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isCreating || !newPromptText}
                    className="w-full bg-red-600 hover:bg-red-700 text-white"
                  >
                    {isCreating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                    Add to Library
                  </Button>
                </form>
              </div>

              {/* List */}
              <div className="lg:col-span-2">
                <div className="bg-background/50 rounded-xl border border-white/5 overflow-hidden">
                  <div className="p-4 border-b border-white/5 flex justify-between items-center">
                    <span className="text-sm font-medium text-muted-foreground">Current Library</span>
                    <span className="text-xs bg-muted px-2 py-1 rounded-full">{basePrompts?.length || 0} items</span>
                  </div>
                  <div className="max-h-[400px] overflow-y-auto p-2 space-y-2">
                    {basePrompts?.map((prompt) => (
                      <div 
                        key={prompt.id} 
                        className="group flex items-start justify-between gap-4 p-3 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/5"
                      >
                        <div className="space-y-1">
                          <span className="inline-block text-[10px] font-bold tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded uppercase mb-1">
                            {prompt.category}
                          </span>
                          <p className="text-sm text-gray-300 leading-snug">{prompt.text}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-muted-foreground hover:text-red-500 hover:bg-red-500/10 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => deletePrompt(prompt.id)}
                          disabled={isDeleting}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    {(!basePrompts || basePrompts.length === 0) && (
                      <div className="p-8 text-center text-muted-foreground text-sm">
                        No base prompts found. Add one to get started.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 mt-12 bg-black/20">
        <div className="max-w-7xl mx-auto px-6 text-center text-muted-foreground text-sm">
          <p>© 2024 AI Prompt Generator. Designed for Creators.</p>
        </div>
      </footer>
    </div>
  );
}
